

<?php
if(isset($_POST['submitsuggestion'])) {
	
}

?>
<?php
/*
// Please specify your Mail Server - Example: mail.yourdomain.com.
require_once('js/class.phpmailer.php');

$name="";
$email="";
$phone="";
$message="";
// the message
if (isset($_POST["name1"])){$name=$_POST['name1'];}
if (isset($_POST["email1"])){$email=$_POST['email1'];}
if (isset($_POST["phone1"])){$phone=$_POST['phone1'];}
if (isset($_POST["message1"])){$message=$_POST['message1'];}

if(isset($name)&&isset($email)&&isset($phone)&&isset($message))
{
	$headers =  'MIME-Version: 1.0' . "\r\n"; 
$headers .= 'From: Your name <info@address.com>' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n"; 

$bodytext = "Name: ".$name."\nEmail: ".$email."\nPhone: ".$phone."\nMessage: ".$message;

// use wordwrap() if lines are longer than 70 characters


// send email
$email = new PHPMailer();
$email->Host = "smtp.secureserver.net"; 
$email->From      = 'you@example.com';
$email->Subject   = 'Contact';
$email->Body      = $bodytext;
$email->AddAddress('ninad.sabnis16@gmail.com');

$email->Send();
header('Location:index.html');
}
 */
 ?>
